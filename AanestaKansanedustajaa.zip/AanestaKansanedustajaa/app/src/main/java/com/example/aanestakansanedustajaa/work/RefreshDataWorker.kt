package com.example.aanestakansanedustajaa.work

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.aanestakansanedustajaa.repository.ParliamentRepository

import retrofit2.HttpException

class RefreshDataWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    companion object {
        const val WORK_NAME = "com.example.aanestakansanedustajaa.work.RefreshDataWorker"
    }

    override suspend fun doWork(): Result {
        Log.d("RecurringWork", "Testing log.d doWork start")
        Log.i("RecurringWork", "Testing log.i doWork start")
        val repository = ParliamentRepository
        try {
            Log.d("RecurringWork", "Testing log.d doWork try")
            Log.i("RecurringWork", "Testing log.i doWork try")
            repository.refreshParliamentDataEntry()
        } catch (e: HttpException) {
            Log.d("RecurringWork", "Testing log.d catch")
            Log.i("RecurringWork", "Testing log.i catch")
            return Result.retry()
        }
        Log.d("RecurringWork", "Testing log.d doWork end")
        Log.i("RecurringWork", "Testing log.i doWork end")
        return Result.success()

    }
}